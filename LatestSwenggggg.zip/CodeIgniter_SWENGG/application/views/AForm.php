<html>
<head></head>
<body>
    <img src="<?php echo base_url(); ?>aformHeader.png" id="afHeader"> <br>
    <br>
	<b> Requesting Organization: </b> La Salle Computer Society <br>
	<b> Title of Activity: </b> LSCS Gen Assembly <br>
	<b> Nature of Activity: </b> CSO & Special Groups -Special Interest <br>
	<b> Type of Activity: </b> Through CSO/DAAM - General Assembly	<br> <br>

	<hr>
	<br>
	<b> <u> ACTIVITY DETAILS</b></u> <br>
	<br>
	<b> Date: </b> March 18, 2017 <br> 
	<b> Time: </b> 9:00-12:30 <br>
	<b> Venue: </b> Bean Bag Room <br>
	<b> ENP: </b> <?php echo $res[0]['ENP']; ?> <br>
	<b> ENMP: </b> <?php echo $res[0]['ENMP']; ?> <br>
	<br>
	<br>
	Submitted By: <br>
	&nbsp;&nbsp;__________________________ &nbsp;&nbsp; &nbsp;&nbsp;_______________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;____________________________ &nbsp;&nbsp; &nbsp;&nbsp;_______________<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Signature Over Printed Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date and Time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Organization President&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date and Time<br><br> <br>

	Noted By: <br>
	&nbsp;&nbsp;__________________________ &nbsp;&nbsp; &nbsp;&nbsp;_______________ &nbsp;&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;Faculty Adviser &nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;USG Treasuerer&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;EB in Charge<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Signature Over Printed Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date and Time<br><br>
	&nbsp;&nbsp;__________________________ &nbsp;&nbsp; &nbsp;&nbsp;_______________ &nbsp;&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;COSCA &nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;LSPO&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;STRATCOM&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;OCCS<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Signature Over Printed Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date and Time<br><br><br>
	
	<center>CSO/DAAM USE ONLY</center>
	<fieldset>
	<b>Status: </b>&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;Approved&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;Pending&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;Denied&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;Please see me ASAP<br>
	<span><b> Comments: </b><br> <fieldset><br><br><br></fieldset></span>	
	</fieldset>

	<br>
	Approved By: <br>
	&nbsp;&nbsp;__________________________ &nbsp;&nbsp; &nbsp;&nbsp;_______________ &nbsp;&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;SLIFE/STC Coordinator &nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;CSO APS&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;USG DAAM<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Signature Over Printed Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Date and Time<br><br>

	<img src="header3.png" id="afHeader"> <br>
	<br> <br><b><u>IN CASE OF CHANGE</u></b><br><br>
	<b> Date: </b> __________________________ <br>
	<b> Time: </b> __________________________ <br>
	<b> Venue: </b>__________________________ <br>

	<b> Changes Approved By: </b>_______________________&nbsp;&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;SLIFE/STC Coordinator &nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;CSO APS&nbsp;&nbsp;<input type="checkbox">&nbsp;&nbsp;USG DAAM<br><br><br>
	Received By:  __________________________ &nbsp;&nbsp;&nbsp;Date/Time: __________________________ <br><br><br>

	<hr>
	<br><b> <u> POST ACTIVITY REQUIREMENTS </u></b> <br><br>
	<b> Due Date: </b> _______________________<br>
	<b> Status: </b>__________________________ <br> <br>
	<input type="checkbox"> &nbsp;&nbsp;Pre-Acts Requirements <br>
	<input type="checkbox"> &nbsp;&nbsp;Attendance Log Sheet <br>
	<input type="checkbox"> &nbsp;&nbsp;List of Expenses <br>
	<input type="checkbox"> &nbsp;&nbsp;List of Pictures <br>
	<input type="checkbox"> &nbsp;&nbsp;Approved Poster/Flyer <br>
	<input type="checkbox"> &nbsp;&nbsp;Sample Publication <br>
	<input type="checkbox"> &nbsp;&nbsp;FRA Report <br>
	<input type="checkbox">&nbsp;&nbsp; Income Statement <br>
	<input type="checkbox">&nbsp;&nbsp; List of Participants and Winners <br>
	<input type="checkbox"> &nbsp;&nbsp;Signed MOA/s <br>
	<input type="checkbox"> &nbsp;&nbsp;Minutes of the Meeting <br>
	<input type="checkbox"> &nbsp;&nbsp;Activity Report <br>
	<input type="checkbox"> &nbsp;&nbsp;Evaluation Results <br>
</body>
</html>