<?php
	class Account_model extends CI_Model {
		public function __construct() {
			$this->load->database();
		}
		
		public function checkLogin($username, $password){
			$this->db->where(array("username" => $username, "password" => $password));
			$this->db->select('usertypeID');
			$this->db->from('ref_users');
			$res = $this->db->get();
			return $res->result_array();
		}
		
		public function getID($username, $password){
			$this->db->where(array("username" => $username, "password" => $password));
			$this->db->select('userID, name, acronym');
			$this->db->from('ref_users');
			$res = $this->db->get();
			return $res->result_array();
		}
		
	}
?>